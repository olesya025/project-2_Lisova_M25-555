# Primitive Database

Простая база данных для управления таблицами с поддержкой основных операций.

## Установка

```bash
# Установка через pipx
pipx install project-2-lisova-m25-555

# Или локальная установка
make build
make package-install