#!/usr/bin/env python3

from .engine import welcome


def main():
    welcome()


if __name__ == "__main__":
    main()